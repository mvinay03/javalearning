package com.project.vehicle.Management.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
